﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula11e12
{
    //Declarações dos delegates que será associados a events
    public delegate void MetodosSemParametros();
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Aula04
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {

        }

        private void FigurasAdicionar_Click(object sender, RoutedEventArgs e)
        {
            WindowAdicionar dlg = new WindowAdicionar();

            if(dlg.ShowDialog() == true)
            {
                canvasFigura.Children.Clear();
                lbFiguras.Items.Add(dlg.Figura);

                switch (dlg.Figura)
                {
                    case "Quadrado":
                        Rectangle quadrado = new Rectangle();
                        quadrado.Width = 50;
                        quadrado.Height = 50;
                        quadrado.Stroke = Brushes.Red;
                        canvasFigura.Children.Add(quadrado);
                        break;
                    case "Retangulo":
                        Rectangle retangulo = new Rectangle();
                        retangulo.Width = 100;
                        retangulo.Height = 50;
                        retangulo.Stroke = Brushes.Red;
                        canvasFigura.Children.Add(retangulo);

                        break;
                    case "Circulo":
                        Ellipse circulo = new Ellipse();
                        circulo.Width = 50;
                        circulo.Height = 50;
                        circulo.Stroke = Brushes.Blue;
                        canvasFigura.Children.Add(circulo);
                        break;
                }
            }
        }

        private void FigurasSair_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        //TPC: Clicar na figura da listbox e desenhar figura respetiva 
        //TPC: Fazer ex 2 extra aula

        //TPC: Fazer exercicio 2 extra aula
        //TPC: Clicar na figura da listbox e desenhar figura 

    }
}

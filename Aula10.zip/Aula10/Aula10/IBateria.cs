﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula10
{
    internal interface IBateria
    {
        //Definição de Propriedades (Características que a classe deve implementar)
        int Carga { get; set; }

        //Definição de Métodos (Comportamentos que a classe deve implementar)
        void Carregar();
        void Descarregar();

        //Definição de eventos (Notificações que a classe deve implementar)
        event MetodosComInt CargaAlterada;
    }
}

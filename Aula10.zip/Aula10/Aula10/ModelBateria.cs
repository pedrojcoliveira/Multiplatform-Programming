﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula10
{
    public class ModelBateria : IBateria
    {
        public int Carga { get; set; }

        public event MetodosComInt CargaAlterada;

        public void Carregar()
        {
            if (Carga < 100)
            {
                Carga += 10;

                //Notificação de alteração de carga (Model->View)
                if (CargaAlterada != null)
                    CargaAlterada(Carga);
            }
            else
            {
                throw new OperacaoInvalidaException("A bateria já está carregada!");
            }
        }

        public void Descarregar()
        {
            if (Carga > 0)
            {
                Carga -= 10;

                //Notificação de alteração de carga (Model->View)
                if (CargaAlterada != null)
                    CargaAlterada(Carga);
            }
            else
            {
                throw new OperacaoInvalidaException("A bateria já está descarregada");
            }
        }


    }
}

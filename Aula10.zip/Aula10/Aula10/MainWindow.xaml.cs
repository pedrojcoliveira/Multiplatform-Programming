﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Aula10
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //Variável que guarda apontador para App (Camada de Interligação)
        private App app;
        public MainWindow()
        {
            InitializeComponent();

            //Obtenção do apontador para App (Camada de Interligação)
            app = App.Current as App;

            //Subscrição de método da View em evento do Model (Model->View)
            app.M_Bateria.CargaAlterada += M_Bateria_CargaAlterada;
        }

        private void M_Bateria_CargaAlterada(int Carga)
        {
            //Atualiza a interface gráfica com o estado da aplicação (Carga)
            this.Title = "Gestor de Bateria - " + Carga + "%";
            pbBateria.Value = Carga;
        }

        private void btnDescarregar_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                //Invocação de métodos do Model (View->Model)
                app.M_Bateria.Descarregar();
            }
            catch (OperacaoInvalidaException erro)
            {
                MessageBox.Show(erro.Message, "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnCarregar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //Invocação de métodos do Model (View->Model)
                app.M_Bateria.Carregar();
            }
            catch(OperacaoInvalidaException erro)
            {
                MessageBox.Show(erro.Message, "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
